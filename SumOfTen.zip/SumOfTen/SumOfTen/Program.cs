﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfTen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n4 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n5 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n6 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n7 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n8 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n9 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            int n10 = Convert.ToInt32(Console.ReadLine());

            double finalValue = (1 + n2 + n3 + n4 + n5 + n6 + n7 + n8 + n9 + n10);
            double avg = (finalValue / 10);
            if (avg < 60)
            {
                Console.WriteLine(" F ");

            }


            if ((avg >= 60) && (avg <= 69))
            {
                Console.WriteLine(" D ");

            }
            if ((avg >= 70) && (avg <= 79))
            {
                Console.WriteLine(" C ");

            }
            if ((avg >= 80) && (avg <= 89))
            {
                Console.WriteLine(" B ");

            }
            if ((avg >= 90) && (avg <= 100));
            {

                Console.WriteLine(" A ");
            }
            Console.Write(finalValue/ 10);
            Console.ReadLine();
        }
    }
}
