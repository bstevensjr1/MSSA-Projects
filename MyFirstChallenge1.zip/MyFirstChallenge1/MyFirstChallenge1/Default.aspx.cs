﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyFirstChallenge1
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void OkButton_Click(object sender, EventArgs e)
        {
            string age = ageBox1.Text;
            string money = moneyBox2.Text;

            string result = " At " + age + " I expected you to have more than " + money + " in your pocket .";
            resultLabel.Text = result;
        }
    }
}